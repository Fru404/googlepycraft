# __init__.py

from .firestoreupload import firestoreupload
